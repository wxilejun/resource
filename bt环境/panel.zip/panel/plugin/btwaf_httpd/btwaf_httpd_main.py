#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 黄文良 <287962566@qq.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   宝塔网站防火墙 for httpd
#+--------------------------------------------------------------------
import sys,os;
p_path = '/www/server/panel/plugin/btwaf_httpd';
sys.path.append(p_path);
reload(sys);
import btwaf_httpd_init;
reload(btwaf_httpd_init);

class btwaf_httpd_main(btwaf_httpd_init.plugin_init):pass;
        
if __name__ == "__main__":
    os.chdir('/www/server/panel')
    p = btwaf_httpd_main();
    p.sync_cnlist(None);
    